#!/bin/sh

sudo ./data/bin/node --harmony ./data/app.js 
