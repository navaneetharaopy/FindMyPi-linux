var app = module.exports = require('appjs'),
    exec = require('child_process').exec;

var allIp = [];

app.serveFilesFrom(__dirname + '/content');
app.router.get('/getip',getAllIp);

var window = app.createWindow({
  width  : 640,
  height : 460,
  icons  : __dirname + '/content/icons'
});

window.on('create', function(){
  console.log("Window Created");

  window.frame.show();
  window.frame.center();
  //window.frame.setMenuBar(menubar);
});

window.on('ready', function(){
  console.log("Window Ready");
  window.process = process;
  window.module = module;

  function F12(e){ return e.keyIdentifier === 'F12' }
  function Command_Option_J(e){ return e.keyCode === 74 && e.metaKey && e.altKey }

  window.addEventListener('keydown', function(e){
    if (F12(e) || Command_Option_J(e)) {
      window.frame.openDevTools();
    }
  });
});

window.on('close', function(){
  console.log("Window Closed");
});

function getAllIp(req,res){
    var allData,nmapProcess;
    exec("sudo nmap -sP 192.168.1.0/24 | awk '/^Nmap/{ip=$NF}/B8:27:EB/{print  $3,ip }'")
    .stdout.on('data',function(data){
        allData = data.split("\n");
        console.log('hi',allData);
        allData.forEach(function(entry){
            if(entry){
                var array = entry.split(" ");
                allIp.push({'MAC' : array[0] , 'IP' : array[1]});
            }
        })
        console.log(allIp);
        return res.send(allIp);
    })
}
